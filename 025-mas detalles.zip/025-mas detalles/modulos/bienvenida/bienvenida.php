<section id="bienvenida">
    <h1>Bienvenidos a TaronjaBox</h1>
    <p>Descubre entrenamientos, fisioterapia y más para mejorar tu rendimiento.</p>
    <a href="modulos/planes-suscripcion/planes-suscripcion.php" class="btn">Ver Planes</a>
</section>
<link rel="stylesheet" href="modulos/bienvenida/bienvenida.css">