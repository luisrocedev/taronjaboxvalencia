<section id="destacado">
    <h2>Destacado</h2>
    <div id="infoDestacado">
        <p>Cargando contenido...</p>
    </div>
</section>

<script src="modulos/destacados/destacados.js"></script>
<link rel="stylesheet" href="modulos/destacados/destacados.css">