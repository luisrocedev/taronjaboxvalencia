<div id="contenido_mantenimiento">
    <div id="mantenimiento">
        <span>⚠️</span>
        <p>Web en mantenimiento - Estaremos contigo de nuevo en breve</p>
    </div>
</div>
<script>
    <?php include "./modulos/modal/control/modal.js" ?>
</script>
<style>
    <?php include "modal.css" ?>
</style>