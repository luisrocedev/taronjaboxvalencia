<!DOCTYPE html>
<html lang="es">

<head>
    <?php include "modulos/header/header.php"; ?>
</head>

<body>
    <?php include "modulos/bienvenida/bienvenida.php"; ?>
    <?php include "modulos/destacados/destacados.php"; ?>
    <?php include "modulos/servicios/servicios.php"; ?>
    <?php include "modulos/footer/footer.php"; ?>
    <?php include "modulos/mantenimiento/mantenimiento.php"; ?>
</body>

</html>