<?php include("../header/header.php"); ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Horarios - TaronjaBox</title>
</head>

<body>

    <section id="horarios">
        <h2>Horarios</h2>
        <div class="horarios-container">
            <img src="img/horario.jpg" alt="Horarios de Clases">
        </div>
    </section>

    <?php include("../footer/footer.php"); ?>

</body>

</html>