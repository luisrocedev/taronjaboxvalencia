<section id="blog">
    <h2>Blog</h2>
    <p>Cargando publicaciones...</p>
</section>
<script src="blog.js"></script>