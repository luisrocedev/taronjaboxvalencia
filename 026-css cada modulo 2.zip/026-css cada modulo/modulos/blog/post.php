<section id="post">
    <p>Cargando post...</p>
</section>
<script src="post.js"></script>