<section id="destacados">
    <h2>Destacados</h2>
    <div class="destacados-container"></div> <!-- Aquí se cargarán los destacados -->
</section>

<template id="destacado-template">
    <div class="destacado">
        <img src="" alt="" class="destacado-img">
        <div class="destacado-content">
            <h3 class="destacado-titulo"></h3>
            <p class="destacado-descripcion"></p>
            <a href="" class="destacado-enlace">Ver más</a>
        </div>
    </div>
</template>