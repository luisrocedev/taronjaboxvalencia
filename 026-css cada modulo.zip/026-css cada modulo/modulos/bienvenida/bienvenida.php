<section id="bienvenida">
    <h1>Bienvenidos a TaronjaBox</h1>
    <p>Tu lugar de crossfit en valencia.</p>
    <a href="modulos/quienes-somos/quienes-somos.php" class="btn">Quienes somos</a>
</section>
<link rel="stylesheet" href="modulos/bienvenida/bienvenida.css">