<footer>
    <div class="footer-container">
        <p>2025 TaronjaBox | Todos los derechos reservados</p>
    </div>

    <style>
        <?php include __DIR__ . "/footer.css"; ?>
    </style>
</footer>