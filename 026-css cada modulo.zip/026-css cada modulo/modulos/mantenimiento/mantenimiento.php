<div id="contenido_mantenimiento">
    <div id="mantenimiento">
        <span>⚠️</span>
        <p>Web en mantenimiento - Estaremos contigo de nuevo en breve</p>
    </div>
</div>
<script>

</script>
<style>
    <?php include "mantenimiento.css" ?>
</style>